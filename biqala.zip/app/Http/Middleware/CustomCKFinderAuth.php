<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class CustomCKFinderAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // ✅ تحديد الـ guard الخاص بلوحة التحكم بدلاً من الـ guard الافتراضي
        config(['ckfinder.authentication' => function() {
            return Auth::guard('admin')->check();
        }]);

        return $next($request);
    }
}
